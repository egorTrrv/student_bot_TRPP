# super_bot

Super Multifunction Comprehensive Absolute Power Ultimative Student Bot (SMCAPUSB)

A bot for the social network "Vkontakte", the purpose of which is to help students of RTU MIREA organize their educational activities.
Functions: shows the schedule, saves homework, finds the name of the teacher, takes notes.
Written in the Python language, using the Vk_api library, as an educational project on the subject of TRPP by MIREA students.